# TradeLog Crypto Journal Pro

Mobile-first starter application: HTML/CSS/JS + Node.js/Express + SQLite + Binance Spot WebSocket + TradingView Lightweight Charts.

## Requirements
- Node.js 18+
- Internet connection for Binance market data and CDN chart library

## Run locally
```bash
npm install
cp .env.example .env
npm start
```
Open http://localhost:3000

Windows PowerShell:
```powershell
Copy-Item .env.example .env
```

## Included
- Mobile-first responsive dashboard and bottom navigation
- Binance Spot market: BTCUSDT, ETHUSDT, SOLUSDT
- REST historical candles + WebSocket live kline updates
- Candlesticks, volume, EMA/SMA 20/50, RSI 14, MACD 12/26/9
- Journal CRUD, open/closed positions, trade notes, screenshot upload
- Entry/SL/TP horizontal chart lines for the selected pair's first open trade
- Win rate, P/L after fees, profit factor, average trade, max drawdown, equity curve
- Calendar P/L and per-pair performance
- JSON backup/import, CSV export, browser print-to-PDF
- PWA manifest and service worker shell cache

## Important implementation notes
- The initial market feed is Binance **Spot**. Selecting FUTURES in a journal record is a journal label only; it does not switch the market data feed to Binance Futures or calculate leveraged margin/funding/liquidation.
- The journal P/L calculation is a simple linear quantity calculation: (exit-entry)*quantity for LONG, inverse for SHORT, less entered fees. It does not model leverage, funding, contract multipliers, partial fills, or exchange-specific fee currencies.
- SQLite is local to the server. Use persistent disk storage when hosting.
- Do not expose this starter publicly without HTTPS, authentication/authorization, rate limiting, secure file handling, backup strategy, and a proper secrets policy. APP_PIN is only a simple optional write/read guard for a single-user private deployment, not full account authentication.
- Screenshot uploads are limited to 5MB and image/jpeg, image/png, image/webp.
- PWA install/service worker requires HTTPS on a deployed domain; localhost is allowed for local development.
- Lightweight Charts is an open-source charting library. Retain the required TradingView attribution/link in public deployments and review its current license/NOTICE requirements.
- This is a journaling/analytics tool, not an exchange terminal and does not place orders.
